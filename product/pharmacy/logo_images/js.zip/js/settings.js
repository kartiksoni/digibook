(function($) {
  'use strict';
  $(function() {
    $(".nav-settings").click(function() {
      $("#right-sidebar").toggleClass("open");
    });
    $(".settings-close").click(function() {
      $("#right-sidebar,#theme-settings").removeClass("open");
    });

    $("#settings-trigger").on("click", function() {
      $("#theme-settings").toggleClass("open");
    });


    //background constants
    var navbar_classes = "navbar-danger navbar-success navbar-warning navbar-dark navbar-light navbar-primary navbar-info navbar-pink";
    var sidebar_classes = "sidebar-light sidebar-dark";
    var $body = $("body");

    //sidebar backgrounds
    $("#sidebar-light-theme").on("click", function() {
      $body.removeClass(sidebar_classes);
      $body.addClass("sidebar-light");
      $(".sidebar-bg-options").removeClass("selected");
      $(this).addClass("selected");
    });
    $("#sidebar-dark-theme").on("click", function() {
      $body.removeClass(sidebar_classes);
      $body.addClass("sidebar-dark");
      $(".sidebar-bg-options").removeClass("selected");
      $(this).addClass("selected");
    });


    //Navbar Backgrounds
    $(".tiles.primary").on("click", function() {
      $(".navbar").removeClass(navbar_classes);
      $(".navbar").addClass("navbar-primary");
      $(".tiles").removeClass("selected");
      $(this).addClass("selected");
    });
    $(".tiles.success").on("click", function() {
      $(".navbar").removeClass(navbar_classes);
      $(".navbar").addClass("navbar-success");
      $(".tiles").removeClass("selected");
      $(this).addClass("selected");
    });
    $(".tiles.warning").on("click", function() {
      $(".navbar").removeClass(navbar_classes);
      $(".navbar").addClass("navbar-warning");
      $(".tiles").removeClass("selected");
      $(this).addClass("selected");
    });
    $(".tiles.danger").on("click", function() {
      $(".navbar").removeClass(navbar_classes);
      $(".navbar").addClass("navbar-danger");
      $(".tiles").removeClass("selected");
      $(this).addClass("selected");
    });
    $(".tiles.pink").on("click", function() {
      $(".navbar").removeClass(navbar_classes);
      $(".navbar").addClass("navbar-pink");
      $(".tiles").removeClass("selected");
      $(this).addClass("selected");
    });
    $(".tiles.info").on("click", function() {
      $(".navbar").removeClass(navbar_classes);
      $(".navbar").addClass("navbar-info");
      $(".tiles").removeClass("selected");
      $(this).addClass("selected");
    });
    $(".tiles.dark").on("click", function() {
      $(".navbar").removeClass(navbar_classes);
      $(".navbar").addClass("navbar-dark");
      $(".tiles").removeClass("selected");
      $(this).addClass("selected");
    });
    $(".tiles.default").on("click", function() {
      $(".navbar").removeClass(navbar_classes);
      $(".tiles").removeClass("selected");
      $(this).addClass("selected");
    });
    
    // For left side bar search added by gautam makwana 10-01-2019
    /*------------------------------------------START------------------------------*/
    var navArray = [];
    var navHtml = $('#sidebar-menu').html();

    $('#sidebar-menu .nav-item a').each(function() {
        var text = $.trim($(this).text());
        var url = $(this).attr('href');
        var nav = []
        nav['text'] = text;
        nav['url'] = url;
        navArray.push(nav);
    });

    $("#searchsidebar").on("keyup", function () {
        var search = $(this).val().toLowerCase();
        var searchArray = [];
        if(search != ''){

            $('.left-sidebar-loader').show();//loader

            $.each(navArray, function(key, value){
              var val = (value['text']).toLowerCase();
              if(val.indexOf(search) >= 0){
                var tmp = [];
                tmp['text'] = value['text'];
                tmp['url'] = value['url'];
                if ($.inArray(value['text'], searchArray.text) == -1 && value['url'].charAt(0) != '#'){
                  searchArray.push(tmp);
                }
              }
            });

            $.ajax({
                type: "POST",
                url: 'ajax_second.php',
                data: {'search':search, 'action':'getCustomerVendor'},
                dataType: "json",
                success: function (data) {
                  if(data.status == true){
                    if(data.result.length > 0){
                      $.each(data.result, function(key, value){
                        var res = [];
                        res['text'] = value.name;
                        res['url'] = (value.group_id == 10) ? 'searchledger.php?customer='+value.id : 'searchledger.php?vendor='+value.id;
                        console.log(res);
                        searchArray.push(res);
                      });
                      searchableResult(searchArray);
                    }else{
                      coonsole.log(searchArray);
                      searchableResult(searchArray);
                    }
                  }else{
                    searchableResult(searchArray);
                  }
                },
                error: function () {
                  searchableResult(searchArray);
                }
            });

            function searchableResult(arrayVal = []){
              if(arrayVal.length > 0){
                $('#sidebar-menu').empty();
                $.each(arrayVal, function(key, value){
                  var append = '<li class="nav-item"><a class="nav-link" href="'+value['url']+'"><i class="fa fa-search"></i> &nbsp;&nbsp;&nbsp;<span class="menu-title">'+value['text']+'</span></a></li>';
                  $('#sidebar-menu').append(append);
                });
              }else{
                $('#sidebar-menu').empty();
                var append = '<li class="nav-item"><a class="nav-link" href="javascript:void(0);"><span class="menu-title text-danger">No Result Found!</span></a></li>';
                $('#sidebar-menu').append(append);
              }
              $('.left-sidebar-loader').hide();//loader
            }

          }else{
            $('.left-sidebar-loader').hide();//loader
            $('#sidebar-menu').html(navHtml);
          }
    });
    /*------------------------------------------END------------------------------*/
    
  });
})(jQuery);