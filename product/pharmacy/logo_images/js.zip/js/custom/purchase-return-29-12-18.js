// author : Kartik Champaneriya
// date   : 10-08-2018
$(document).ready(function(){

  var current_statecode = $('#current_statecode').val();

  $('body').on('click', '.btn-addmore-product', function() {
        var totalproduct = $('.product-tr').length;//for product length
        var html = $('#html-copy').html();
        html = html.replace('##SRPRODUCT##',totalproduct);
       /* html = html.replace('##SRNO##',totalproduct);
        html = html.replace('##SRPRODUCT##',totalproduct);
        html = html.replace('##PRODUCTCOUNT##',totalproduct);*/
        html = html.replace('##PRODUCTCOUNT##',totalproduct);
        html = html.replace('<table>','');
        html = html.replace('</table>','');
        html = html.replace('<tbody>','');
        html = html.replace('</tbody>',''); 
        $('#product-tbody').append(html);
        if(totalproduct <= '2'){
          $('.remove_last').show();
        }
  });

  // Remove product button js //

    $('body').on('click', '.btn-remove-product', function(e) {
        e.preventDefault();
        $(this).closest ('tr').remove ();
        //$('.f_amount').trigger("change");
        $('.f_rate').trigger("change");
    });

    // End Remove product button js // 

  
  $.widget('custom.mcautocomplete', $.ui.autocomplete, {
          _create: function () {
              this._super();
              this.widget().menu("option", "items", "> :not(.ui-widget-header)");
          },
          _renderMenu: function (ul, items) {
              var self = this,
                  thead;
              if (this.options.showHeader) {
                  table = $('<div class="ui-widget-header" style="width:100%"></div>');
                  $.each(this.options.columns, function (index, item) {
                      table.append('<span style="padding:0 4px;float:left;width:' + item.width + ';">' + item.name + '</span>');
                  });
                  table.append('<div style="clear: both;"></div>');
                  ul.append(table);
              }
              $.each(items, function (index, item) {
                  self._renderItem(ul, item);
              });
          },
          _renderItem: function (ul, item) {
              var t = '',
                  result = '';
              $.each(this.options.columns, function (index, column) {
                  t += '<span style="padding:0 4px;float:left;width:' + column.width + ';">' + item[column.valueField ? column.valueField : index] + '</span>'
              });
              result = $('<li></li>')
                  .data('ui-autocomplete-item', item)
                  .append('<a class="mcacAnchor">' + t + '<div style="clear: both;"></div></a>')
                  .appendTo(ul);
              return result;
          }
  });

  $('body').on('keyup click', '.tags ', function () {
        var $this = $(this);
        $(this).mcautocomplete({
        // These next two options are what this plugin adds to the autocomplete widget.
            showHeader: true,
            columns: [{
                name: 'Name',
                width: '200px;',
                valueField: 'name'
            }, {
                name: 'Qty',
                width: '100px',
                valueField: 'total_qty'
            }, {
                name: 'Batch',
                width: '200px',
                valueField: 'batch'
            }/*, {
                name: 'Generic Name',
                width: '250px;',
                valueField: 'generic_name'
            }*/, {
                name: 'MRP',
                width: '100px',
                valueField: 'mrp'
            }, {
                name: 'Expiry Date',
                width: '150px',
                valueField: 'expiry'
            }, {
                name: 'GST',
                width: '50px',
                valueField: 'igst'
            }],

            // Event handler for when a list item is selected.
            select: function (event, ui) {
              this.value = (ui.item ? ui.item.name : '');

              $(this).closest('tr').find('.product-id').val(ui.item.id);
              $(this).closest('tr').find('.qty-value').val(ui.item.ratio);
              $(this).closest('tr').find('.purchase-id').val(ui.item.sgst);
              $(this).closest('tr').find('.mrp').val(ui.item.mrp);
              $(this).closest('tr').find('.mfg_no').val(ui.item.mfg_company);
              $(this).closest('tr').find('.batch_no').val(ui.item.batch);
              $(this).closest('tr').find('.expiry').val(ui.item.expiry);

              if($('#statecode').val() == current_statecode){
                $(this).closest('tr').find('.f_igst').val(0);
                $(this).closest('tr').find('.f_cgst').val(ui.item.cgst);
                $(this).closest('tr').find('.f_sgst').val(ui.item.sgst);
              }else{
                $(this).closest('tr').find('.f_igst').val(ui.item.igst);
                $(this).closest('tr').find('.f_cgst').val(0);
                $(this).closest('tr').find('.f_sgst').val(0);
              }
              
              if(typeof ui.item.expired !== 'undefined' && ui.item.expired == 1){
                  $(this).closest('tr').find('.expired').html('Expired!');
              }else{
                  $(this).closest('tr').find('.expired').html('');
              }
              return false;
            },

            // The rest of the options are for configuring the ajax webservice call.
            minLength: 1,
            source: function (request, response) {
                $.ajax({
                    url: 'ajax.php',
                    dataType: 'json',
                    type: "POST",
                    data: {
                        query: request.term,
                        action: "searchProductWithExpired"
                    },
                    // The success event handler will display "No match found" if no items are returned.
                    success: function (data) {
                      if(data.status == true){
                        $($this).closest('tr').find('.producterror').empty();
                        response(data.result)
                      }else{
                        $($this).closest('tr').find('.producterror').text("No results found");
                      }

                    }
                });
            }
        });
    });

    $('body').on('change', '#vendor_id', function() {
      var statecode = $(this).find(':selected').attr('data-id');
      $('#statecode').val(statecode);
    });

  $('body').on('propertychange change keyup focusout past', '.qty', function() {
      var f_rate = $(this).closest('tr').find('.f_rate').val();
      var qty = $(this).val();
       if(f_rate !== ''&& f_rate !== NaN && f_rate !== "undifined"){
          f_rate = (typeof f_rate !== "undifined" && f_rate !== '' && f_rate !== NaN) ? f_rate : 0;
          qty = (typeof qty !== "undifined" && qty !== '' && qty !== NaN) ? qty : 0;
          var total = (parseFloat(qty)*parseFloat(f_rate));
       }else{
        var total ="0";
       }
      $(this).closest('tr').find('.ammout').val(total);
      $(this).closest('tr').find('.f_rate').trigger("change");
      //$('.ammout').trigger("change");
  });

  $('body').on('propertychange change keyup focusout past', '.f_rate', function() {
      var qty = $(this).closest('tr').find('.qty').val();
      var f_rate = $(this).val();
       if(qty !== ''&& qty !== NaN && qty !== "undifined"){
          f_rate = (typeof f_rate !== "undifined" && f_rate !== '' && f_rate !== NaN) ? f_rate : 0;
          qty = (typeof qty !== "undifined" && qty !== '' && qty !== NaN) ? qty : 0;
          var total = (parseFloat(qty)*parseFloat(f_rate));
       }else{
        var total ="0";
       }
       console.log(total);
      $(this).closest('tr').find('.ammout').val(parseFloat(total).toFixed(2));
      $('.ammout').trigger("change");
  });

  $('body').on('propertychange change keyup focusout past', '.discount', function() {
      var totalamount = 0;
      var discount = $(this).val();
      var rate = $(this).closest('tr').find('.rate').val();
      if(rate !== ''&& rate !== NaN && rate !== "undifined"){
        rate = (typeof rate !== "undifined" && rate !== '' && rate !== NaN) ? rate : 0;
        discount = (typeof discount !== "undifined" && discount !== '' && discount !== NaN) ? discount : 0;
        var total = (parseFloat(rate)-parseFloat(discount));
      }else{
        var total = "0";
      }
      $(this).closest('tr').find('.f_rate').val(total);
      $(this).closest('tr').find('.f_rate').trigger("change");
      //$('.ammout').trigger("change");
  });

  $('body').on('propertychange change keyup focusout past', '.rate', function() {
      var totalamount = 0;
      var rate = $(this).val();
      var discount = $(this).closest('tr').find('.discount').val();
      rate = (typeof rate !== "undifined" && rate !== '' && rate !== NaN) ? rate : 0;
      discount = (typeof discount !== "undifined" && discount !== '' && discount !== NaN) ? discount : 0;
      var total = (parseFloat(rate)-parseFloat(discount));
      $(this).closest('tr').find('.f_rate').val(total);
      $(this).closest('tr').find('.f_rate').trigger("change");
      //$('.ammout').trigger("change");
    });



    $('body').on('change', '.ammout', function() {

      var totalamount = 0;
      var total_igst = 0;
      var total_cgst = 0;
      var total_sgst = 0;

        $('.ammout').each(function() {
          var val = $.trim( $(this).val() );
          if(val){
              val = parseFloat( val.replace( /^\$/, "" ) );
              totalamount += !isNaN( val ) ? val : 0;
          }

          /*--------------------CALCULATE GST START-----------------*/
          val = (!isNaN(val) && val != '') ? parseFloat(val) : 0;
          var igst = $(this).closest('tr').find('.f_igst').val();
          igst = (!isNaN(igst) && igst != '') ? parseFloat(igst) : 0;
          var cgst = $(this).closest('tr').find('.f_cgst').val();
          cgst = (!isNaN(cgst) && cgst != '') ? parseFloat(cgst) : 0;
          var sgst = $(this).closest('tr').find('.f_sgst').val();
          sgst = (!isNaN(sgst) && sgst != '') ? parseFloat(sgst) : 0;

          total_igst += (val*igst/100);
          total_cgst += (val*cgst/100);
          total_sgst += (val*sgst/100);

          /*--------------------CALCULATE GST END------------------*/

        });

      $('#totalamount').val(parseFloat(totalamount).toFixed(2));

      $('#totaligst').val(parseFloat(total_igst).toFixed(2));
      $('#totalcgst').val(parseFloat(total_cgst).toFixed(2));
      $('#totalsgst').val(parseFloat(total_sgst).toFixed(2));

      var finalamount = (totalamount+total_igst+total_cgst+total_sgst);
      $('#finalamount').val(parseFloat(finalamount).toFixed(2));
    });

});

    