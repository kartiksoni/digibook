$( document ).ready(function() {


    var htmlsuccess = '<div class="row"><div class="col-md-12"><div class="alert alert-icon alert-success alert-dismissible fade in" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><i class="mdi mdi-check-all"></i>##MSG##</div></div></div>';
    var htmlerror = '<div class="row"><div class="col-md-12"><div class="alert alert-icon alert-danger alert-dismissible fade in" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><i class="mdi mdi-check-all"></i>##MSG##</div></div></div>';
    var msglength = 0;

    getAllMessage();

    $('body').on('click', '.profile-list-item', function() {
        var $this = $(this);
        $("li").removeClass("active-user");
        $($this).addClass("active-user");
        $('.usr-notification').html(null);
        getAllMessage();
    });

    /*-------------------SEND MESSAGE TO USER START---------------*/
    $('body').on('click', '#btn-send-msg', function() {
        var message = $('#msg').val();
        message = message.trim();
        var to = $('.active-user').attr('data-id');

        if(message !== '' && to !== ''){
            sendMessage(to, message);
        }else{
            return false;
        }
    });

    $("#msg").keypress(function (evt) {
        if (evt.keyCode == 13 && !evt.shiftKey) {

            var message = $('#msg').val();
            message = message.trim();
            var to = $('.active-user').attr('data-id');

            if(message !== '' && to !== ''){
                sendMessage(to, message);
            }else{
                return false;
            }
        }
    });
    /*-------------------SEND MESSAGE TO USER END----------------*/

    /*------------UPLOAD ATTECHMENT START--------------------*/
    $('body').on('click', '#attechment-lable', function(event) {
        $('#attechment').val(null);
        $(".progress-bar").css("width", "0%");
    });
    $('body').on('change', '#attechment', function(event) {

        var tmp_success = htmlsuccess;
        var tmp_error = htmlerror;

        var file_data = $('#attechment').prop('files')[0];
        var form_data = new FormData();
        form_data.append('file', file_data);
        
        $.ajax({
            url: 'upload-attechment.php',
            dataType: 'json', // what to expect back from the PHP script
            cache: false,
            contentType: false,
            processData: false,
            data: form_data,
            type: 'post',
            xhr: function(){
                //upload Progress
                var xhr = $.ajaxSettings.xhr();
                if (xhr.upload) {
                    xhr.upload.addEventListener('progress', function(event) {
                        var percent = 0;
                        var position = event.loaded || event.position;
                        var total = event.total;
                        if (event.lengthComputable) {
                            percent = Math.ceil(position / total * 100);
                        }
                        //update progressbar
                        $(".progress-bar").css("width", + percent +"%");
                        // $(progress_bar_id + " .status").text(percent +"%");
                    }, true);
                }
                return xhr;
            },
            beforeSend: function() {
                 $('.progress').show();
            },
            success: function (data) {
                if(data.status == true){
                    var to = $('.active-user').attr('data-id');
                    var text = data.result;
                    sendMessage(to, text, 1);
                }else{
                    tmp_error = tmp_error.replace("##MSG##", data.message);
                    $('#chat-error').html(tmp_error);
                }
                $('.progress').hide();
            },
            error: function () {
                $('.progress').hide();
                tmp_error = tmp_error.replace("##MSG##", 'File upload fail! Try again.');
                $('#chat-error').html(tmp_error);
                return false;
            }
        });
    });
    /*------------UPLOAD ATTECHMENT END--------------------*/

    /*------------------------FUNCTION START-----------------------*/
    function sendMessage(to = null, msg = null, file = 0){
        var tmp_success = htmlsuccess;
        var tmp_error = htmlerror;
        var from = $('#current_userid').val();
        $.ajax({
            type: "POST",
            url: 'ajaxchat.php',
            data: {'to':to, 'msg': msg, 'file':file, 'action':'sendMessage'},
            dataType: "json",
            success: function (data) {
            if(data.status == true){
                $('#msg').val(null);
                msglength++;

                var text = (file == 0) ? msg : '<a href="../attechment/'+from+'/'+msg+'" target="_blank">'+msg+'</a>';
                var append = '<div class="mail-list"><div class="content"><p class="sender-name"><span class="pull-right">You</span><small class="pull-left text-muted">'+moment().format('MM-DD-YYYY HH:mm')+'</small></p><p class="message_text text-right">'+text+'</p></div></div>';
                $('#chatdiv').append(append);
                scrollDown();
                return false;
            }else{
                tmp_error = tmp_error.replace("##MSG##", data.message);
                $('#chat-error').html(tmp_error);
                return false;
            }
          },
          error: function () {
            tmp_error = tmp_error.replace("##MSG##", 'Somthing Want Wrong! Try Again.');
            $('#chat-error').html(tmp_error);
            return false;
          }
        });
    }
    
    function getAllMessage(){
        var to = $('.active-user').attr('data-id');
        if(typeof to != 'undefined' && to != ''){
            $.ajax({
                type: "POST",
                url: 'ajaxchat.php',
                data: {'to':to, 'action':'getAllMessage'},
                dataType: "json",
                beforeSend: function() {
                    $('#chat-loader').show();
                    $('#chatdiv').html(null);
                    $( "#msg" ).prop( "disabled", true );
                    $('.profile-list').css('pointer-events', 'none');
                },
                success: function (data) {
                    // set unread notification
                    if(typeof data.unread !== 'undefined'){
                        unreadNotification(data.unread);
                    }
                    $('.profile-list').css('pointer-events', 'auto');

                    if(data.status == true){
                        var current_userid = $('#current_userid').val();
                        var html = '';

                        $.each(data.result, function (key, value) {
                            var align = (value.fromid == current_userid) ? 'right' : 'left';
                            var textalign = (value.fromid == current_userid) ? 'left' : 'right';
                            var text = (value.file == 1) ? '<a href = "'+value.url+'" target="_blank">'+value.text+'</a>' : value.text;
                            var unm = (value.fromid == current_userid) ? 'You' : value.fromname;
                            html = html + '<div class="mail-list"><div class="content"><p class="sender-name"><span class="pull-'+align+'">'+unm+'</span><small class="pull-'+textalign+' text-muted">'+value.msgdate+'</small></p><p class="message_text text-'+align+'">'+text+'</p></div></div>';
                        });
                        
                        msglength = (data.result.length != '') ? data.result.length : 0;
                        
                        setTimeout(function(){
                            $('#chatdiv').html(html);
                            scrollDown();
                            $('#chat-loader').hide();
                            $( "#msg" ).prop( "disabled", false );
                        }, 500);
                    }else{
                        $('#chatdiv').empty();
                        $('#chat-loader').hide();
                        $( "#msg" ).prop( "disabled", false );
                        return false;
                    }
              },
              error: function () {
                $('#chatdiv').empty();
                $('#chat-loader').hide();
                $( "#msg" ).prop( "disabled", false );
                $('.profile-list').css('pointer-events', 'auto');
                return false;
              }
            });
        }else{
            return false;
        }
    }

    setInterval(getLiveMessage,2000);
    function getLiveMessage(){
        var totalmsg_length = (msglength != '') ? msglength : 0;
        var to = $('.active-user').attr('data-id');

        if(to != ''){
            $.ajax({
                type: "POST",
                url: 'ajaxchat.php',
                data: {'to':to, 'length': totalmsg_length, 'action':'getLiveMessage'},
                dataType: "json",
                success: function (data) {
                    // set unread notification
                    if(typeof data.unread !== 'undefined'){
                        unreadNotification(data.unread);
                    }

                    if(data.status == true){
                        
                        $.each(data.result, function (key, value) {
                            var text = (value.file == 1) ? '<a href = "'+value.url+'" target="_blank">'+value.text+'</a>' : value.text;
                            var html = '<div class="mail-list"><div class="content"><p class="sender-name"><span class="pull-left">'+value.fromname+'</span><small class="pull-right text-muted">'+value.msgdate+'</small></p><p class="message_text">'+text+'</p></div></div>';
                            $('#chatdiv').append(html);
                        });
                        var datamsglength = (data.result.length != '') ? data.result.length : 0;
                        msglength = (msglength + datamsglength);
                        scrollDown();
                    }else{
                        return false;
                    }
                  },
              error: function () {
                return false;
              }
            });
        }else{
            console.log('msglength => '+msglength);
            return false;
        }
        console.log('msglength => '+msglength);
    }

    function scrollDown(){
        $('#chatdiv').animate({scrollTop: $('#chatdiv')[0].scrollHeight}, 0);
    }

    function unreadNotification(arr = []){
        if(typeof arr != 'undefined' && arr != '' && arr.length > 0){
            $.each(arr, function (key, value) {
                if(typeof value.id !== 'undefined' && typeof value.count !== 'undefined' && value.count > 0){
                    $('#notification'+value.id).html(value.count);
                }
            });
        }
    }
    /*------------------------FUNCTION START-----------------------*/
});