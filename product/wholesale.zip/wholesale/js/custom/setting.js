$(document).ready(function(){
    $(".setting").click(function(){
        window.location.href = $(this).data('href'); 
    });
});