<?php $title="Journal Vouchar"; ?>
<?php include('include/usertypecheck.php');?>
<?php include('include/permission.php'); ?>
<?php

  $owner_id = (isset($_SESSION['auth']['owner_id'])) ? $_SESSION['auth']['owner_id'] : '';
  $admin_id = (isset($_SESSION['auth']['admin_id'])) ? $_SESSION['auth']['admin_id'] : '';
  $pharmacy_id = (isset($_SESSION['auth']['pharmacy_id'])) ? $_SESSION['auth']['pharmacy_id'] : '';
  $financial_id = (isset($_SESSION['auth']['financial'])) ? $_SESSION['auth']['financial'] : '';
  
  if(isset($_GET['id'])){
    $editquery = "SELECT id, voucher_date, remarks, is_file, file_name FROM `journal_vouchar`WHERE id ='".$_GET['id']."' AND pharmacy_id = '".$pharmacy_id."'";
    $editresult = mysqli_query($conn,$editquery);

    if($editresult && mysqli_num_rows($editresult) > 0){
      $editdata = mysqli_fetch_assoc($editresult);
      if(isset($editdata['id']) && $editdata['id'] != ''){
        $editsubQuery = "SELECT * FROM journal_vouchar_details WHERE voucher_id = '".$editdata['id']."'";
        $editsubRes = mysqli_query($conn, $editsubQuery);
        if($editsubRes && mysqli_num_rows($editsubRes) > 0){
          while ($editsubRow = mysqli_fetch_assoc($editsubRes)) {
            $ledger = countRunningBalance($editsubRow['particular']);
            $editsubRow['running_balance'] = (isset($ledger['running_balance']) && $ledger['running_balance'] != '') ? $ledger['running_balance'] : 0;
            $editdata['detail'][] = $editsubRow;
          }
        }
      }
    }
  }

  
  if(isset($_POST['submit'])){
    $count = (isset($_POST['type']) && !empty($_POST['type'])) ? count($_POST['type']) : 0;
    if($count > 0){
      $voucher_date = (isset($_POST['voucher_date']) && $_POST['voucher_date'] != '') ? date('Y-m-d',strtotime(str_replace('/','-',$_POST['voucher_date']))) : NULL;
      $remarks = (isset($_POST['remarks'])) ? $_POST['remarks'] : '';
      
      $is_file = (isset($_POST['is_file']) && $_POST['is_file'] == 1) ? 1 : 0;
      
      if(($is_file == 1) && (isset($_FILES['file_name']) && !empty($_FILES['file_name']))){
        if (!file_exists('journal_voucher_file')) {
		    mkdir('journal_voucher_file', 0777, true);
		}
		
		$filename = $_FILES['file_name']['name'];
		$filename = preg_replace("/\.[^.]+$/", "", $filename);
		$ext = pathinfo($_FILES['file_name']['name'], PATHINFO_EXTENSION);
		$final_filename = $filename . '_'. mt_rand(100000,999999) . "." . $ext;
		$target_path = 'journal_voucher_file/'.$final_filename;
		if(!move_uploaded_file($_FILES['file_name']['tmp_name'], $target_path)) {  
		    $_SESSION['msg']['fail'] = "Record save fail! Because file not uploaded please try again.";
            header('Location:'.basename($_SERVER['PHP_SELF']));exit;
		}
      }else{
          $final_filename = '';
      }
      
      if(isset($_GET['id']) && $_GET['id'] != ''){
        $query = "UPDATE journal_vouchar SET ";
      }else{
        $query = "INSERT INTO journal_vouchar SET financial_id = '".$financial_id."', owner_id = '".$owner_id."', admin_id = '".$admin_id."', pharmacy_id = '".$pharmacy_id."', ";
      }
      $query .= "voucher_date = '".$voucher_date."', remarks = '".$remarks."', is_file = '".$is_file."', file_name = '".$final_filename."', ";

      if(isset($_GET['id']) && $_GET['id'] != ''){
        $query .= "modified = '".date('Y-m-d H:i:s')."', modifiedby = '".$_SESSION['auth']['id']."' WHERE id = '".$_GET['id']."'";
      }else{
        $query .= "created = '".date('Y-m-d H:i:s')."', createdby = '".$_SESSION['auth']['id']."'";
      }
      
      $res = mysqli_query($conn, $query);
      if($res){
          $voucher_id = (isset($_GET['id']) && $_GET['id'] != '') ? $_GET['id'] : mysqli_insert_id($conn);
          if(isset($_GET['id']) && $_GET['id'] != ''){
            $deleteQ = "DELETE FROM journal_vouchar_details WHERE voucher_id = '".$_GET['id']."'";
            mysqli_query($conn, $deleteQ);
          }
          for ($i=0; $i < $count; $i++) { 
            $type = (isset($_POST['type'][$i])) ? $_POST['type'][$i] : NULL;
            $particular = (isset($_POST['particular'][$i])) ? $_POST['particular'][$i] : NULL;
            $debit = (isset($_POST['debit'][$i]) && $_POST['debit'][$i] != '') ? $_POST['debit'][$i] : 0;
            $credit = (isset($_POST['credit'][$i]) && $_POST['credit'][$i] != '') ? $_POST['credit'][$i] : 0;

            $subquery = "INSERT INTO journal_vouchar_details SET voucher_id = '".$voucher_id."', type = '".$type."', particular = '".$particular."', debit = '".$debit."', credit = '".$credit."', created = '".date('Y-m-d H:i:s')."', createdby = '".$_SESSION['auth']['id']."'";
            mysqli_query($conn, $subquery);
          }
          if(isset($_GET['id']) && $_GET['id'] != ''){
            $_SESSION['msg']['success'] = "Voucher update successfully";
          }else{
            $_SESSION['msg']['success'] = "Voucher added successfully";
          }
      }else{
        if(isset($_GET['id']) && $_GET['id'] != ''){
          $_SESSION['msg']['fail'] = "Voucher update fail! Try again.";
        }else{
          $_SESSION['msg']['fail'] = "Voucher added fail! Try again.";
        }
      }
      header('Location:'.basename($_SERVER['PHP_SELF']));exit;
    }else{
      $_SESSION['msg']['fail'] = "Somthing Want Wrong! Try again.";
      header('Location:'.basename($_SERVER['PHP_SELF']));exit;
    }
  }
?>

<?php
    if(isset($_GET['download']) && $_GET['download'] != ''){
        download('journal_voucher_file/'.$_GET['download']);
    }
    if(isset($_GET['remove']) && $_GET['remove'] != ''){
        $findFileQ = "SELECT id, file_name FROM journal_vouchar WHERE pharmacy_id = '".$pharmacy_id."' AND id='".$_GET['remove']."'";
        $findFileR = mysqli_query($conn, $findFileQ);
        if($findFileR && mysqli_num_rows($findFileR) > 0){
            $findFileRow = mysqli_fetch_assoc($findFileR);
            $filename = (isset($findFileRow['file_name'])) ? $findFileRow['file_name'] : '';
            if(file_exists('journal_voucher_file/'.$filename)){
                if(!unlink('journal_voucher_file/'.$filename)){
                    $_SESSION['msg']['fail'] = "Attechment Remove Fail! Try again.";
                    header('Location:journal-vouchar.php?id='.$_GET['remove']);exit;
                }
            }
            $update = mysqli_query($conn, "UPDATE journal_vouchar SET is_file = 0, file_name = '' WHERE id = '".$_GET['remove']."'");
            if($update){
                $_SESSION['msg']['success'] = "Attechment Remove Successfully";
                header('Location:journal-vouchar.php?id='.$_GET['remove']);exit;
            }else{
                $_SESSION['msg']['fail'] = "Attechment Remove Fail! Try again.";
                header('Location:journal-vouchar.php?id='.$_GET['remove']);exit;
            }
        }else{
            $_SESSION['msg']['fail'] = "Somthing Want Wrong! Try again.";
            header('Location:journal-vouchar.php?id='.$_GET['remove']);exit;
        }
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>DigiBooks</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="vendors/iconfonts/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/iconfonts/puse-icons-feather/feather.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  
   <!-- plugin css for this page -->
  <link rel="stylesheet" href="vendors/icheck/skins/all.css">
  
  <!-- plugin css for this page -->
  <link rel="stylesheet" href="vendors/iconfonts/font-awesome/css/font-awesome.min.css" />
  <link rel="stylesheet" href="vendors/iconfonts/simple-line-icon/css/simple-line-icons.css">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="images/favicon.png" />

  <link rel="stylesheet" href="css/parsley.css">
  <link rel="stylesheet" href="css/toggle/style.css">
</head>
<body>
  <div class="container-scroller">
  
    <!-- Topbar -->
    <?php include "include/topbar.php" ?>
    
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
        
    <!-- Right Sidebar -->
    <?php include "include/sidebar-right.php" ?>
        
       
    <!-- Left Navigation -->
    <?php include "include/sidebar-nav-left.php" ?>
      
      <div class="main-panel">
        <div class="content-wrapper">
          <?php include('include/flash.php'); ?>
          <div class="row">
          
           <!-- Form -->
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <!-- Main Catagory -->
                  <div class="row">
                    <div class="col-12">
                        <div class="purchase-top-btns">
                            <?php if((isset($user_sub_module) && in_array("Cash Management", $user_sub_module)) || $_SESSION['auth']['user_type'] == "owner"){ ?>
                                <a href="accounting-cash-management.php" class="btn btn-dark active">Cash Management</a>
                            <?php } if((isset($user_sub_module) && in_array("Customer Receipt", $user_sub_module)) || $_SESSION['auth']['user_type'] == "owner"){ ?>
                                <a href="accounting-customer-receipt.php" class="btn btn-dark btn-fw">Customer Receipt</a>
                            <?php } if((isset($user_sub_module) && in_array("Cheque", $user_sub_module)) || $_SESSION['auth']['user_type'] == "owner"){ ?>
                                <a href="accounting-cheque.php" class="btn btn-dark  btn-fw">Cheque</a>
                            <?php } if((isset($user_sub_module) && in_array("Vendor Payment", $user_sub_module)) || $_SESSION['auth']['user_type'] == "owner"){ ?>
                                <a href="accounting-vendor-payments.php" class="btn btn-dark  btn-fw">Vendor Payment</a>
                            <?php } if((isset($user_sub_module) && in_array("Financial Year Settings", $user_sub_module)) || $_SESSION['auth']['user_type'] == "owner"){ ?>
                                <a href="financial-year.php" class="btn btn-dark  btn-fw">Financial Year Settings</a>
                            <?php } if((isset($user_sub_module) && in_array("Credit Note / Purchase Note", $user_sub_module)) || $_SESSION['auth']['user_type'] == "owner"){ ?>
                                <a href="purchase-return.php" class="btn btn-dark  btn-fw">Credit Note / Purchase Note</a>
                            <?php } 
                            /// Changes By Kartik in this module reseller Only ///
                            //if(isset($user_sub_module) && in_array("Quotation / Estimate / Proformo Invoice", $user_sub_module)){ 
                            ?>
                            <!--<a href="quotation.php" class="btn btn-dark  btn-fw">Quotation / Estimate / Proformo Invoice</a>-->
                            <?php //} 
                            if((isset($user_sub_module) && in_array("Journal Vouchar", $user_sub_module)) || $_SESSION['auth']['user_type'] == "owner"){
                            ?>
                            <a href="journal-vouchar.php" class="btn btn-dark  btn-fw">Journal Vouchar</a>
                            <?php } ?>
                        </div>   
                    </div> 
                  </div>
                  <hr/>
                  <form method="POST" autocomplete="off" enctype="multipart/form-data">
                    <div class="form-group row">
                      <div class="col-12 col-md-2 offset-md-10">
                        <input type="text" name="voucher_date" value="<?php echo (isset($editdata['voucher_date']) && $editdata['voucher_date'] != '') ? date('d/m/Y',strtotime($editdata['voucher_date'])) : date('d/m/Y'); ?>" class="form-control datepicker" placeholder="DD/MM/YYYY" required>
                      </div>
                    </div>
                    <table id="entryTable" class="table">
                      <thead>
                        <tr>
                          <th width="30%">Type</th>
                          <th width="30%">Particulars</th>
                          <th width="15%">Debit</th>
                          <th width="15%">Credit</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody id="product-tbody">
                          <?php if(isset($editdata['detail']) && !empty($editdata['detail'])){ ?>
                            <?php foreach ($editdata['detail'] as $key => $value) { ?>
                              <tr>
                                  <td>
                                      <select class="form-control js-example-basic-single type" name="type[]" required data-parsley-errors-container="#error-type" style="width: 100%;">
                                        <option value="">Select</option>
                                        <?php 
                                          $groupQry = "SELECT * FROM `group`";
                                          $group = mysqli_query($conn,$groupQry);
                                          while($group_data = mysqli_fetch_assoc($group)){
                                        ?>
                                          <option value="<?php echo $group_data['id']; ?>"  <?php echo (isset($value['type']) && $value['type'] == $group_data['id']) ? 'selected' : ''; ?> ><?php echo $group_data['name']; ?></option> 
                                               
                                        <?php } ?>         
                                      </select>
                                      <span id="error-type"></span>
                                  </td>
                                    
                                  <td>
                                      <?php 
                                        if(isset($value['type']) && $value['type'] != ''){
                                          $editPerticularData = [];
                                          $getPerticularQ = "SELECT id, name FROM ledger_master WHERE group_id = '".$value['type']."' AND status = 1 AND pharmacy_id = '".$pharmacy_id."'";
                                          $getPerticularR = mysqli_query($conn, $getPerticularQ);
                                          if($getPerticularR && mysqli_num_rows($getPerticularR) > 0){
                                            while ($getPerticularRow = mysqli_fetch_assoc($getPerticularR)) {
                                              $editPerticularData[] = $getPerticularRow;
                                            }
                                          }
                                        }
                                      ?>

                                      <select class="form-control js-example-basic-single particular" name="particular[]" style="width:100%;" required data-parsley-errors-container="#error-particular">
                                        <option value="">Select Particulars</option>
                                        <?php 
                                          if(isset($editPerticularData) && !empty($editPerticularData)){
                                            foreach ($editPerticularData as $keys => $values) {
                                        ?>
                                          <option value="<?php echo $values['id']; ?>"  <?php echo (isset($value['particular']) && $value['particular'] == $values['id']) ? 'selected' : ''; ?> ><?php echo $values['name']; ?></option>
                                        <?php 
                                            }
                                          }
                                        ?>
                                      </select>
                                      <span id="error-particular"></span>
                                      <div class="badge badge-primary pull-right ledger_running_balance">
                                        <?php 
                                            if(isset($value['running_balance']) && $value['running_balance'] != ''){
                                                echo amount_format(number_format(abs($value['running_balance']), 2, '.', ''));
                                                echo ($value['running_balance'] > 0) ? ' Dr' : ' Cr';
                                            }
                                        ?>
                                      </div>
                                  </td>

                                  <td>
                                      <input type="text" name="debit[]" value="<?php echo (isset($value['debit'])) ? $value['debit'] : ''; ?>" class="form-control debit" placeholder="enter debit amount">
                                  </td>

                                  <td>
                                    <input type="text" required name="credit[]" value="<?php echo (isset($value['credit'])) ? $value['credit'] : ''; ?>" class="form-control credit" placeholder="enter credit amount">
                                  </td>

                                  <td>
                                    <a href="javascript:;" id="addmore" class="btn btn-primary btn-xs pt-2 pb-2 btn-addmore-product addmore"><i class="fa fa-plus mr-0 ml-0"></i></a>
                                    <a href="javascript:;" class="btn btn-danger btn-xs pt-2 pb-2 btn-remove-product "><i class="fa fa-close mr-0 ml-0"></i></a>
                                  </td>
                              </tr>
                            <?php } ?>
                          <?php }else{ ?>

                            <tr id="tr1" >

                                <td>
                                    <select class="form-control js-example-basic-single type" style="width:100%" name="type[]" required data-parsley-errors-container="#error-type1">
                                        <option value="">Select</option>
                                        <?php 
                                          $groupQry = "SELECT * FROM `group`";
                                          $group = mysqli_query($conn,$groupQry);
                                          while($group_data = mysqli_fetch_assoc($group)){
                                        ?>

                                        
                                            <option value="<?php echo $group_data['id']; ?>"  ><?php echo $group_data['name']; ?></option> 
                                               
                                        <?php } ?>         
                                    </select>
                                    <span id="error-type1"></span>
                                </td>
                                  
                                <td>
                                  <select class="form-control js-example-basic-single particular" style="width:100%" name="particular[]" required data-parsley-errors-container="#error-particular1">
                                    <option value="">Select Particulars</option>
                                  </select>
                                  <span id="error-particular1"></span>
                                  <div class="badge badge-primary pull-right ledger_running_balance"></div>
                                </td>

                                <td>
                                    <input type="text" name="debit[]"  class="form-control debit onlynumber" placeholder="enter debit amount">
                                </td>

                                <td>
                                  <input type="text" name="credit[]" class="form-control credit onlynumber" placeholder="enter credit amount">
                                </td>

                                <td>
                                  <a href="javascript:;" class="btn btn-primary btn-xs pt-2 pb-2 btn-addmore-product addmore"><i class="fa fa-plus mr-0 ml-0"></i></a>
                                </td>

                            </tr>
                          <?php } ?>

                      </tbody>

                    </table>
                    <div class="row form-group">
                        <div class="col-md-6">
                            <textarea class="form-control" name="remarks" id="remarks" placeholder="Ener Remarks"><?php echo (isset($editdata['remarks'])) ? $editdata['remarks'] : ''; ?></textarea>    
                        </div>
                        <div class="col-md-1">
                            <div class="sales-filter-btns-right display-3">
                                <div class="form-check">
                                  <label class="form-check-label">
                                    <input <?php if(isset($editdata['is_file']) && $editdata['is_file'] == "1"){echo "checked"; } ?> type="checkbox"  id="is_file" value="1" class="form-check-input ModuleChange" name="is_file">
                                    File
                                  </label>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-5 <?php echo (isset($editdata['is_file']) && $editdata['is_file'] == 1) ? 'display-block' : 'display-none'; ?>" id="file_upload_div" style="padding-top:15px;">
                            <?php if((isset($editdata['file_name']) && $editdata['file_name'] != '') && file_exists('journal_voucher_file/'.$editdata['file_name'])){ ?>
                                <span><i class="fa fa-paperclip"></i> <a href="?download=<?php echo $editdata['file_name']; ?>"><?php echo $editdata['file_name']; ?></a>  &nbsp;&nbsp;<a href="?remove=<?php echo $editdata['id']; ?>" class="text-danger" onclick="return confirm('Are you sure you want to remove this attechment?');"><i class="fa fa-trash-o"></i></a></span>
                            <?php }else{ ?>
                                <input type="file" name="file_name" class="form-control">
                            <?php } ?>
                        </div>
                    </div>
                    <a href="view-journal-vouchar.php" class="btn btn-light mt-30 pull-left" name="submit">Back</a>
                    <button name="submit" type="submit" class="btn btn-success mt-30 pull-right" style="float:right;"><?php echo (isset($_GET['id']) && $_GET['id'] != '') ? 'Update Voucher' : 'Add Voucher'; ?></button>
                  </form>

                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        
        <!-- partial:partials/_footer.php -->
        <?php include "include/footer.php" ?>
        <!-- partial -->
        
          
        <!-- Add New Product Model -->
        <?php include "include/addproductmodel.php" ?>
     
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <div id="product-tr" style="display: none">
    <table>
      <tr id="##PRODUCTCOUNT##"  >
        <td>
          <select class="form-control type" style="width: 100%;" name="type[]" required>
              <option value="">Select</option>
              <?php 
                $groupQry = "SELECT * FROM `group`";
                $group = mysqli_query($conn,$groupQry);
                while($group_data = mysqli_fetch_assoc($group)){
              ?>
                  <option value="<?php echo $group_data['id']; ?>"  ><?php echo $group_data['name']; ?></option>   
              <?php } ?>         
          </select>
        </td>
                      
        <td>
          <select class="form-control particular" style="width: 100%;" name="particular[]" required>
            <option value="">Select Particulars</option>
          </select>
          <div class="badge badge-primary pull-right ledger_running_balance"></div>
        </td>

        <td>   
          <input type="text" name="debit[]" class="form-control debit onlynumber" placeholder="enter debit amount">
        </td>

        <td>
          <input type="text" name="credit[]"  class="form-control credit onlynumber" placeholder="enter credit amount">
        </td>

        <td>
          <a href="javascript:;" class="btn btn-primary btn-xs pt-2 pb-2 btn-addmore-product addmore"><i class="fa fa-plus mr-0 ml-0"></i></a>
          <a href="javascript:;" class="btn btn-danger btn-xs pt-2 pb-2 btn-remove-product "><i class="fa fa-close mr-0 ml-0"></i></a>
        </td>   
      </tr>
    </table>
  </div>
  

  <!-- plugins:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <script src="vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/misc.js"></script>
  <script src="js/settings.js"></script>
  <script src="js/todolist.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/file-upload.js"></script>
  <script src="js/iCheck.js"></script>
  <script src="js/typeahead.js"></script>
  <script src="js/select2.js"></script>
  
  <!-- Custom js for this page-->
  <script src="js/formpickers.js"></script>
  <script src="js/form-addons.js"></script>
  <script src="js/x-editable.js"></script>
  <script src="js/dropify.js"></script>
  <script src="js/dropzone.js"></script>
  <script src="js/jquery-file-upload.js"></script>
  <script src="js/formpickers.js"></script>
  <script src="js/form-repeater.js"></script>
  
  <!-- Custom js for this page Modal Box-->
  <script src="js/modal-demo.js"></script>
  <!-- Custom js for this page Datatables-->
  <script src="js/data-table.js"></script> 
  <script>
     $('.datatable').DataTable();
     $('.datepicker').datepicker({
        enableOnReadonly: true,
        todayHighlight: true,
        format: 'dd/mm/yyyy',
        autoclose : true
      });
  </script>

  <script src="js/parsley.min.js"></script>
  <script type="text/javascript">
    $('form').parsley();
  </script>
  <script src="js/custom/onlynumber.js"></script>
  <script src="js/custom/journal_vouchar.js"></script>
  
  
  <!-- End custom js for this page-->
</body>


</html>
